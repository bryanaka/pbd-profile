module SamlHelper
end

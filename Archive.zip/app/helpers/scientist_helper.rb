module ScientistHelper
end

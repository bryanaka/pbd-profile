class ScientistTitle < ActiveRecord::Base
  attr_accessible :scientist_id, :title
end

class ScientistWebsite < ActiveRecord::Base
  attr_accessible :description, :name, :scientist_id, :url
end

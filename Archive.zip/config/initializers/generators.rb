Rails.application.config.generators do |g|
end

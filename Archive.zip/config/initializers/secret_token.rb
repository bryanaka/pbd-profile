# Be sure to restart your server when you modify this file.

# Your secret key for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!
# Make sure the secret is at least 30 characters and all random,
# no regular words or you'll be exposed to dictionary attacks.
PbdPortal::Application.config.secret_token = '3d5493f2ddc2f17156c2e8b6b2516c1227a3f2d32454d6b7e8ab793f4701388b050705f1f05725d66585b0ffea1c83bf0b5991093fbf97d3acacf96e16c79d6c'

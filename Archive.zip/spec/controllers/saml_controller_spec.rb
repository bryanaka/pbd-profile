require 'spec_helper'

describe SamlController do

end

Fabricator(:scientist) do
  first_name "MyString"
  last_name  "MyString"
  picture    "MyString"
  title      "MyString"
  slug       "MyString"
end

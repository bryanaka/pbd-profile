Fabricator(:scientist_title) do
  title        "MyString"
  scientist_id 1
end

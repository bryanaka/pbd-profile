Fabricator(:scientist_website) do
  name         "MyString"
  url          "MyString"
  description  "MyString"
  scientist_id 1
end

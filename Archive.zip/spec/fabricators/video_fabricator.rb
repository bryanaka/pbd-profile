Fabricator(:video) do
  title       "MyString"
  scientist   ""
  description "MyText"
  date        "2013-02-24"
  vid_type    "MyString"
  vid_code    "MyString"
  poster      "MyString"
  views       1
  vid_link    "MyString"
end

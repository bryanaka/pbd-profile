require 'spec_helper'

describe Scientist do
  pending "add some examples to (or delete) #{__FILE__}"
end
